const myForm = document.getElementById("login-form");

myForm.addEventListener("submit", event => {

    let username = document.getElementsById("idusername");
    let password = document.getElementsById("idpassword");
    let message = document.getElementById("idMessage");

    if(username.length == 0 && password.length == 0){
        
    }
    else if(username.length == 0){

    }
    else{

    }
});